

<?php $__env->startSection('title'); ?>
    Живой поиск 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <h1 class="mb-3">Живой поиск</h1>

    <form id="liveSearchForm" method="POST" action="<?php echo e(route('live-search-search')); ?>" class="inline-flex gap-4 mt-10 mb-10"
        role="search">
        <?php echo csrf_field(); ?>
        <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search"
            id="searchInput" name="s2">
            <button class="btn btn-danger" type="submit">Отправить</button>
    </form>

    <div id="searchResults">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Имя пользователя: <?php echo e($user->name); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\php\laravel-new\resources\views/live-search.blade.php ENDPATH**/ ?>