

<?php $__env->startSection('title'); ?>
    О нас 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <h1 class="mb-3">О нас </h1>

    <div class="inner">
        
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\php\laravel-new\resources\views/about.blade.php ENDPATH**/ ?>