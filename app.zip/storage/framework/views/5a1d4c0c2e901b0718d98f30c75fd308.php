<p>Имя: <?php echo e($formData['name']); ?></p>
<p>Тема: <?php echo e($formData['subject']); ?></p>
<p>Сообщение: <?php echo e($formData['message']); ?></p><?php /**PATH C:\www\php\laravel-new\resources\views/emails/email_form.blade.php ENDPATH**/ ?>