

<?php $__env->startSection('title'); ?>
    Отзывы
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <h1>Отзывы</h1>

    <hr>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <br>

    <h2>Форма добавления отзыва</h2>
    <form method="POST" action="/reviews/check">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Имя</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Введите ваше имя">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email адрес</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="name@example.com">
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Сообщение</label>
            <textarea class="form-control" name="message" id="message" rows="3"></textarea>
        </div>

        <button type="submit" class="btn btn-success">Отправить отзывы</button>
    </form>
    <h2 class="m-4">Отзывы</h2>
    <hr>

     <h2 class="m-4">Поиск по отзывам</h2>
    <form method="get" action="<?php echo e(route('search')); ?>" class="inline-flex gap-4 mb-10" role="search">
        <input type="search" class="form-control form-control-dark text-bg-dark" id="s" name="s" placeholder="Search..." aria-label="Search">
        <button type="submit" class="btn btn-success">Поиск</button>                
     </form>
    <br>
    <ul class="grid grid-cols-3 gap-5">
        <?php if($reviews->isNotEmpty()): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="p-4 border rounded-lg">
                    <h3 class="text-xl mb-2"><?php echo e($el->name); ?></h3>
                    <p class="text-slate-300 mb-2"><?php echo e($el->email); ?></p>
                    <p class="mb-4"><?php echo e($el->message); ?></p>
                    <a href="<?php echo e(route('review-one', $el->id)); ?>" class="btn btn-success">Подробнее</a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="p-7">
            <?php echo e($reviews->links()); ?>

        </div>

        <?php else: ?>
            ничего не найдено
        <?php endif; ?>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\php\laravel-new\resources\views/reviews.blade.php ENDPATH**/ ?>