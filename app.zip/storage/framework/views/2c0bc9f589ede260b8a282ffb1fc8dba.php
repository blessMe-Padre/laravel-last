

<?php $__env->startSection('title'); ?>
    <?php echo e($data->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <h1>Отзыв</h1>
    <br>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <br>
    <hr>
    <div class="row gap-5">
        <div class="alert alert-warning col">
            <h3><?php echo e($data->name); ?></h3>
            <p><?php echo e($data->email); ?></p>
            <p><?php echo e($data->massage); ?></p>

            <a href="/reviews" class="btn btn-success">Назад</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\php\laravel-new\resources\views/review.blade.php ENDPATH**/ ?>