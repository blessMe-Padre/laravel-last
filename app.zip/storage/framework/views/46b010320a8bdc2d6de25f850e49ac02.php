

<?php $__env->startSection('title'); ?>
Написать письмо
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
<h1 class="mb-3">Написать письмо</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('send-email-post')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Имя</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Введите ваше имя" value="<?php echo e(old('name')); ?>">
            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Почта</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Введите вашу почту" value="<?php echo e(old('email')); ?>">
            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        </div>

        <div class="mb-3">
            <label for="subject" class="form-label">Тема письма</label>
            <input type="text" name="subject" class="form-control" id="subject" placeholder="Введите тему письма" value="<?php echo e(old('subject')); ?>">
            <span class="text-danger"><?php echo e($errors->first('subject')); ?></span>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Телефон</label>
            <input type="tel" name="phone" class="form-control" id="phone" placeholder="+7900000000" value="<?php echo e(old('phone')); ?>">
            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>

        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Сообщение</label>
            <textarea class="form-control" name="message" id="message" rows="3"></textarea>
            <span class="text-danger"><?php echo e($errors->first('message')); ?></span>

        </div>

        <button type="submit" class="btn btn-success">Отправить письмо</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\php\laravel-new\resources\views/mail.blade.php ENDPATH**/ ?>