@extends('layout')

@section('title')
    О нас 
@endsection

@section('main_content')
    <h1 class="mb-3">О нас </h1>

    <div class="inner">
        
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
        <p class="text-xl font-bold mb-6 underline">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa vel
            molestiae doloribus illo nobis quaerat
            eligendi veniam a sint voluptatem, vitae, ducimus modi libero velit. Dolor asperiores quos modi eos.</p>
    </div>
@endsection