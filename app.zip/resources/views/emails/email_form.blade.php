<p>Имя: {{$formData['name']}}</p>
<p>Почта: {{$formData['email']}}</p>
<p>Тема: {{$formData['subject']}}</p>
<p>Телефон: {{$formData['phone']}}</p>
<p>Сообщение: {{$formData['message']}}</p>